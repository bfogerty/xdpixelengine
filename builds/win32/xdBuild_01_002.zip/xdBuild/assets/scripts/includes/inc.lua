
function t()
    test("Hello World", "Test2");
end

