dofile("includes/inc.lua")

--[[
function t()
    test("Hello World", "Test2");
end
--]]

t();
